import React from "react";

export default function Rodape() {
    return (
        <footer className="rodape">
            <p>&copy; 2024 Yza Senac. Todos os direitos reservados.</p>
        </footer>
    );
}
