import React from "react";
import './styles.css';

export default function Rodape(){
    return(
        <div>
             <footer>
        <p>&copy; 2024 Yza Senac. Todos os direitos reservados.</p>
    </footer>
        </div>
    )
}