import React, { useState, useContext } from 'react';
import { AutenticadoContextoo } from '../Contexts/authContext';
import { Link } from 'react-router-dom'
import { toast } from 'react-toastify' 
import './login.css';

export default function Inicio() {

    const loginEntrada = useContext(AutenticadoContextoo);

  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  async function dadosLogin (e) {
    e.preventDefault();
    if(!email || !senha ){
        toast.warning('preencha todos os campos')
        return
    }
    try {
        await loginEntrada (email, senha)
    } catch (error) {
        
    }
    console.log('Email:', email);
    console.log('Senha:', senha);
  };

  return (
    <div className="login-container">
      <h2> Login</h2>
      <form onSubmit={dadosLogin}>
        <div>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Senha:</label>
          <input
            type="password"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            required
          />
        </div>
        <button type="submit">Entrar</button>
      </form>
      <p>Para se cadastrar clique <Link to='/'>AQUI</Link> </p>
    </div>
  );
};

