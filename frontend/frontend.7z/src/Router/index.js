import React, { useContext } from "react";
import { AutenticadoContextoo } from "../Contexts/authContext";


import NaoAutenticados from '../Router/NaoAutenticados.routes';
import Autenticados from "./Autenticados.routes";

export default function Rotas(){

    const { Autenticado } = useContext (AutenticadoContextoo)

    return(
        <>
        {Autenticado === true ? <Autenticados /> : <NaoAutenticados/>}
        </>
    )
}