import React from 'react'

export default function DashboardEmpresa(){
    return(
<div class='obrigado'>
            <h1><center>Dados Gravados Com Sucesso!!</center></h1>
            <h4>Obrigado Por Nos Escolher</h4>
            <a href='/'><button>Voltar ao Inicio</button></a>
        </div>
       
    )
}